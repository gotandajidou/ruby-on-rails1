class WelcomeController < ApplicationController
    def say
    end
    
    def index
    end
end
