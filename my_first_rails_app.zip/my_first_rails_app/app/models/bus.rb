class Bus < ApplicationRecord
end
